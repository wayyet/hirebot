---
name: example-digital-employee-agents
description: >
  示例数字员工：展示标准的工作流程与能力模块定义。
---

# 示例数字员工 — Agents

> 说明：这是一个示例数字员工，展示标准的工作流程定义方式。

## 交付物
- 交付物A（Output Type A）
- 交付物B（Output Type B）
- 交付物C（Output Type C）

## 工作流程

```mermaid
graph TD
  A[输入：用户请求/任务] --> B{识别任务类型}
  B -->|类型A| C[处理流程A：分析+输出]
  B -->|类型B| D[处理流程B：查询+汇总]
  B -->|类型C| E[处理流程C：推理+建议]
  C --> F{质量检查}
  D --> F
  E --> F
  F -->|通过| G[输出交付物+下一步行动]
  F -->|不通过| H[列出缺口+需要补充的信息]
  H --> B
  G --> I[记录关键结论]
  I --> B
```

## Skill 分配
| 模块 | 对应 Skill | 作用 |
|---|---|---|
| 模块A | skill-example-a | 描述该Skill的功能 |
| 模块B | skill-example-b | 描述该Skill的功能 |
| 模块C | skill-example-c | 描述该Skill的功能 |
