# 评估说明

## 1. 模板基本信息

- 模板名称：示例数字员工 (example-digital-employee)
- 模板版本：v1.0.0
- 来源：标准示例模板
- 关联沙箱：未提供
- 关联会话：未提供

## 2. 评估目标

当前模板为标准化示例数字员工模板，用于展示数字员工模板的完整结构与字段定义。

优先验证以下能力：
- 基础连通性与角色识别
- 基本任务响应能力

## 3. 测试用例概览

| 用例 ID | 场景名称 | 类型 | 预期结果 |
| --- | --- | --- | --- |
| CONN-001 | 基础连通性与角色识别 | connectivity | 用户能够确认该模板已经可用并理解其职责范围。 |
| ROLE-001 | 基本任务响应验证 | role_task | 能够完成基本任务处理，结果对用户有价值。 |

## 4. 评估维度

- 业务维度：accuracy、completeness、compliance、communication
- 执行维度：functional_completeness、interaction_quality、process_compliance、problem_resolution、tool_call_correctness
- 映射说明：accuracy 侧重功能完成度与问题解决；compliance 侧重流程合规与工具调用正确性；communication 侧重交互质量。

## 5. 测试材料

- `evaluation.md`：当前评估说明文档
- `evaluation/testcases.json`：结构化测试用例
- 用例来源：标准示例模板基础骨架。

## 6. 说明

- 这是一个示例模板，评估材料为占位内容。
- 自定义数字员工时，请根据实际业务场景重新生成评估材料。
