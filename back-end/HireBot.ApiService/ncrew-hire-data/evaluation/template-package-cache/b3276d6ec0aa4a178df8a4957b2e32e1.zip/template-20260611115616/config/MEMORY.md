﻿---
name: customer-info-collector-memory
description: >
  客户信息收集员记忆管理：三层记忆架构（L1会话/L2业务库/L3规则库）及调用策略。
---

# 客户信息收集员 — Memory

> 记忆管理 | NCrew 配置层

---

## L1 — Session Memory（会话层）

当前研究任务的上下文，任务完成后归档。

| 字段 | 类型 | 内容 |
|------|------|------|
| `sessionId` | string | 会话唯一标识 |
| `triggerSource` | string | 触发来源（销售输入/系统定时/团队协作）|
| `enterpriseName` | string | 目标企业名称 |
| `demandClue` | string | 需求线索（销售提供的一句话）|
| `verificationResult` | EnterpriseProfile | 工商核验结果 |
| `rawInformationList` | RawInformation[] | 本次检索的原始信息列表 |
| `structuredInfo` | StructuredInfo | 本次整理的结构化信息 |
| `fiveLookAnalysis` | FiveLookAnalysis | 本次五看分析结果 |
| `threeDecideSpeculation` | ThreeDecideSpeculation | 本次三定推测结果 |
| `painPointSpeculations` | PainPointSpeculation[] | 本次痛点推测列表 |
| `report` | Report | 本次生成的报告 |
| `createdAt` | Date | 创建时间 |
| `updatedAt` | Date | 最后更新时间 |

**调用策略**：研究任务启动时加载，任务完成后将 `structuredInfo` 和 `report` 写入 L2（用于积累客户画像库）。

---

## L2 — Business Memory（业务库层）

客户情报数据的持久化存储，跨会话持续维护。

| 字段 | 内容 |
|------|------|
| `enterpriseProfileDB` | 企业画像库（已完成研究的企业画像，含时间戳）|
| `reportArchive` | 报告归档（历史报告，支持7天复用/30天增量刷新）|
| `industryTagSystem` | 行业标签体系（按行业分类的企业标签）|
| `competitorInfoDB` | 竞品信息库（主要竞品的基本信息与动态）|
| `sourceQualityDB` | 信源质量评估库（各信源的历史质量评分）|
| `painPointAccuracyDB` | 痛点推测命中率记录（用户反馈的推测准确性）|
| `talkCardTemplates` | 谈资速查模板库（按行业/场景分类的谈资模板）|
| `customAnalysisDimensionDB` | 自定义分析维度库（客户定制的分析维度配置）|

**调用策略**：每次研究任务时查询客户画像库（避免重复研究），完成后更新画像库与报告归档。

---

## L3 — Rule Memory（规则库层）

情报研究规则和阈值的配置存储。

| 字段 | 内容 |
|------|------|
| `minSourceCount` | 信源底线数量（默认15）|
| `cacheValidDays` | 缓存有效天数（默认7天）|
| `incrementalRefreshDays` | 增量刷新天数（默认30天）|
| `confidenceThresholdHigh` | 高置信度阈值（默认0.8）|
| `confidenceThresholdMedium` | 中置信度阈值（默认0.5）|
| `sourcePriorityList` | 信源优先级列表（官方>权威媒体>行业报告>社交媒体）|
| `industrySpecificDimensions` | 行业特有分析维度配置 |
| `reportTemplateConfig` | 报告模板配置（结构/格式/输出形式）|

**调用策略**：系统初始化时加载，变更时更新。

---

## 记忆调用流程

```
研究任务触发（企业名 + 需求线索）
    ↓
加载 L1 Session Memory
    ↓
查询 L2 Business Memory
    → 检查企业画像库（7天内有报告？直接复用）
    → 检查30天内历史报告（增量刷新动态部分）
    → 查询行业标签（确定分析维度）
    ↓
执行工商核验 → 多信源检索 → 信息整理 → 五看三定分析
    ↓
生成报告 + 谈资速查表
    ↓
任务完成
    → L1 结构化信息写入 L2 企业画像库
    → L1 报告写入 L2 报告归档
    → L1 信源质量评分写入 L2 信源质量库
    ↓
定期 → L2 痛点命中率统计 → 更新 L3 分析维度建议
```
