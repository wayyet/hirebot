﻿---
name: customer-info-collector-agents
description: >
  客户信息收集员 Multi-Agent 架构定义：核验器 / 检索器 / 分析器
  三个 Agent 的职责分工、A2A 数据包协议和情报研究流程调度逻辑。
---

# 客户信息收集员 — Agents

> Multi-Agent 架构定义 | NCrew 配置层

---

## 核心使命

通过三个专职 Agent 的流水线协作，将散落在公开信源中的零散企业信息，提炼为销售可直接使用的结构化客户画像与战略分析报告。

客户信息收集员的独特价值：**不是信息搬运，而是情报分析**。从工商核验到多信源检索，从原始信息整理到五看三定洞察，每个环节都有AI精准处理。

---

## Agent 列表

### Agent 1: Verifier（核验器）

| 属性 | 内容 |
|------|------|
| **角色** | 企业身份的感知层，负责工商核验与基本信息确认 |
| **职责** | 接收企业名称 → 调用工商API核验 → 确认企业身份 → 提取基本工商信息 |
| **负责 Skill** | enterprise-verification |
| **决策权** | 判断企业身份是否确认，核验失败时阻断后续流程 |

### Agent 2: Searcher（检索器）

| 属性 | 内容 |
|------|------|
| **角色** | 信息采集核心，负责并发多信源检索与原始信息整理 |
| **职责** | 接收核验后的企业信息 → 并发多信源检索 → 评估信源质量 → 结构化整理原始信息 → 确保信源覆盖≥15个 |
| **负责 Skill** | multi-source-search, information-structuring |
| **决策权** | 决定信源优先级与检索策略，信源不足时触发兜底机制 |

### Agent 3: Analyst（分析器）

| 属性 | 内容 |
|------|------|
| **角色** | 洞察提炼核心，负责五看三定分析、痛点推测与报告生成 |
| **职责** | 接收结构化信息 → 执行五看三定分析 → 推测核心痛点 → 生成谈资速查 → 输出结构化报告 |
| **负责 Skill** | five-look-three-decide, report-generation |
| **决策权** | 决定推测的置信度评分，低置信度区域标注建议验证方向 |

---

## Skill 分配表

| Agent | 负责 Skill | required |
|-------|-----------|----------|
| Verifier | enterprise-verification | ✅ |
| Searcher | multi-source-search | ✅ |
| Searcher | information-structuring | ✅ |
| Analyst | five-look-three-decide | ✅ |
| Analyst | report-generation | ✅ |

---

## A2A 数据包协议

### Verifier → Searcher：VerifiedEnterprisePacket

```typescript
interface VerifiedEnterprisePacket {
  // 企业核验结果
  verification: {
    enterpriseName: string;        // 标准企业名称
    unifiedSocialCode: string;     // 统一社会信用代码
    legalPerson: string;           // 法人代表
    registeredCapital: string;     // 注册资本
    businessScope: string;         // 经营范围
    establishedDate: string;       // 成立时间
    registeredAddress: string;     // 注册地址
    operatingStatus: string;       // 经营状态
  };
  // 核验质量
  quality: {
    verificationConfidence: number;  // 核验置信度 0-1
    dataSource: string;              // 核验数据来源
  };
  // 需求线索（销售提供）
  demandClue?: string;              // 需求线索
  packetId: string;
  createdAt: string;
}
```

**传递条件**：`quality.verificationConfidence >= 0.9`，否则标记 `verification_failed` 并提示人工确认

---

### Searcher → Analyst：StructuredInfoPacket

```typescript
interface StructuredInfoPacket {
  // 结构化信息
  structuredInfo: {
    basicProfile: {
      revenue?: string;             // 营收规模
      employeeCount?: string;       // 员工数量
      recentDynamics: Dynamic[];    // 近期动态列表
    };
    industryContext: {
      industryName: string;         // 所属行业
      industryTrends: string[];     // 行业趋势
      marketSize?: string;          // 市场规模
    };
    competitorInfo: {
      mainCompetitors: string[];    // 主要竞品
      marketPosition?: string;      // 市场地位
    };
    demandClueAnalysis: {
      clue: string;                 // 原始需求线索
      relatedInfo: string[];        // 相关信息
    };
  };
  // 信源评估
  sourceAssessment: {
    totalSourceCount: number;       // 信源总数
    sourceCategories: {             // 信源分类
      official: number;             // 官方来源
      media: number;                // 权威媒体
      industry: number;             // 行业报告
      social: number;               // 社交媒体
    };
    overallCoverage: number;        // 信息覆盖度 0-1
    lowCoverageAreas: string[];     // 低覆盖领域
  };
  // 关联数据
  verification: VerifiedEnterprisePacket['verification'];
  packetId: string;
  createdAt: string;
}
```

**传递条件**：`sourceAssessment.totalSourceCount >= 15`，否则触发兜底机制补充检索

---

### Analyst → User：ReportPacket

```typescript
interface ReportPacket {
  // 报告内容
  report: {
    enterpriseProfile: EnterpriseProfile;    // 企业画像
    fiveLookAnalysis: FiveLookAnalysis;      // 五看分析
    threeDecideSpeculation: ThreeDecideSpeculation;  // 三定推测
    painPoints: PainPointSpeculation[];      // 痛点推测
    talkCard: TalkCard;                      // 谈资速查表
  };
  // 质量评估
  quality: {
    sourceCount: number;               // 信源总数
    informationCompleteness: number;    // 信息完整度 0-1
    avgConfidence: number;             // 平均置信度
    lowConfidenceAreas: string[];       // 低置信度领域
    suggestedNextSteps: string[];       // 建议进一步研究方向
  };
  // 元数据
  cacheInfo?: {
    isFromCache: boolean;               // 是否来自缓存
    originalReportDate?: string;        // 原始报告日期
    refreshedSections?: string[];       // 刷新的部分
  };
  packetId: string;
  createdAt: string;
}
```

**传递条件**：报告必须包含≥15个信源引用，低置信度领域必须标注

---

## Agent 协作流程

```
用户输入：企业名称 + 需求线索
    ↓
[Verifier: enterprise-verification]
    → 调用工商API核验企业身份
    → 提取基本工商信息（法人/注册资本/经营范围等）
    → verificationConfidence < 0.9 → 标记 verification_failed
    ↓
[Searcher: multi-source-search]
    → 接收 VerifiedEnterprisePacket
    → 并发多信源检索（DeepSeek主力 + 千问/智谱兜底）
    → 信源 < 15 → 触发兜底机制补充检索
    → 评估信源质量与覆盖度
    ↓
[Searcher: information-structuring]
    → 将原始信息按五看分类整理
    → 评估信息完整度
    → 标注低覆盖领域
    → 生成 StructuredInfoPacket
    ↓
[Analyst: five-look-three-decide]
    → 接收 StructuredInfoPacket
    → 执行五看分析（行业/客户/对手/自己/机会）
    → 推导三定推测（战略/目标/路径 | 标注置信度）
    → 推测核心痛点（含推测依据与置信度）
    ↓
[Analyst: report-generation]
    → 生成结构化报告（企业画像→五看→三定→痛点→谈资）
    → 标注每个关键结论的信源与置信度
    → 生成谈资速查表（1页纸）
    → 标注低置信度区域与建议验证方向
    ↓
输出结构化报告 + 谈资速查表
```

---

## 技术交付物

| 交付物 | 说明 | 格式 |
|--------|------|------|
| **客户画像报告** | 按"五看三定"框架组织的结构化分析报告 | Markdown / PDF / Word |
| **信源清单** | 报告引用的所有信源列表（含URL与采集时间） | Markdown / JSON |
| **置信度评估表** | 关键结论的置信度评分与信源支撑 | Markdown / JSON |
| **痛点推测卡片** | 推测的客户3-5个核心痛点 | Markdown / JSON |
| **谈资速查表** | 拜访时可直接使用的谈资要点（1页纸） | Markdown |

---

## 核心数据类型

### EnterpriseProfile
```typescript
{
  standardName: string;            // 标准企业名称
  unifiedSocialCode: string;       // 统一社会信用代码
  legalPerson: string;             // 法人代表
  registeredCapital: string;       // 注册资本
  businessScope: string;           // 经营范围
  establishedDate: string;         // 成立时间
  registeredAddress: string;       // 注册地址
  operatingStatus: string;         // 经营状态
  revenue?: string;                // 营收规模（推测）
  employeeCount?: string;          // 员工数量（推测）
}
```

### RawInformation
```typescript
{
  sourceId: string;                // 信源标识
  sourceType: 'official' | 'media' | 'industry' | 'social';
  sourceUrl: string;               // 信源URL
  content: string;                 // 原始内容
  collectedAt: string;             // 采集时间
  qualityScore: number;            // 质量评分 0-1
  relatedCategory: string;         // 关联五看分类
}
```

### PainPointSpeculation
```typescript
{
  painPointId: string;
  description: string;             // 痛点描述
  evidence: string[];              // 推测依据
  confidence: number;              // 置信度 0-1
  suggestedAngle: string;          // 建议切入角度
  status: 'high_confidence' | 'needs_validation' | 'speculative';
}
```

---

## 成功指标

| 指标 | 目标 | 验证方式 |
|------|------|---------|
| 工商核验准确率 | ≥ 99% | 与官方工商数据比对 |
| 信源覆盖度 | ≥ 15个/份报告 | 自动统计信源数量 |
| 报告关键信息完整度 | ≥ 90% | 用户反馈评分 |
| 痛点推测命中率 | ≥ 60% | 用户反馈验证 |
| 报告生成时间 | ≤ 15分钟 | 自动统计 |
| 用户满意度评分 | ≥ 4.0/5.0 | 用户评分 |

---

## 绝对红线

1. **不编造信息** — 每条信息必须有信源支撑
2. **不混淆事实与推测** — 事实标注信源，推测标注置信度
3. **不低于信源底线** — 信源<15时必须触发兜底机制
4. **不绕过工商核验** — 核验失败时阻断后续流程

---

## Action 类型

| Action | 定义 |
|--------|------|
| `verify` | 调用工商API核验企业身份，提取基本工商信息 |
| `search` | 并发多信源检索，收集企业公开信息 |
| `structure` | 将原始信息按五看分类整理，评估信息完整度 |
| `analyze` | 执行五看三定分析，推测痛点，评估置信度 |
| `generate` | 生成结构化报告与谈资速查表 |
| `cache` | 检查缓存/增量刷新，避免重复研究 |
