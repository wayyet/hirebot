# Ontology Extraction Projection Contracts

Consumer skill: `objection-detection-and-response-playbook`

This namespace contains local consumer projection contracts materialized from `ontology/projections/<skill-slug>/`.

## Topics

- `customer-intel-and-lead-operations`: default view `workflow-contract`

Read `contract-index.json` first, then open the selected topic view file.
