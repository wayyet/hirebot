# Ontology Slice — customer-intel-and-lead-operations

## Slice Request
- **Topic:** customer-intel-and-lead-operations
- **Objective:** Support pre-sales customer intelligence collection, lead qualification, objection handling, decision-chain mapping, and CRM-ready structured outputs.
- **Expected deliverables:**
  - Customer profile card
  - Lead grading (A/B/C) and opportunity maturity
  - Decision chain mapping
  - Objection playbook
  - Sales risk alert and next actions
  - CRM field payload (generic B2B template)

## Scope
### In scope
- Customer basic information fields
- Project background fields
- Customer profiling (digitalization/AI maturity)
- Key needs tags
- Decision roles and relationship hints
- Objection categories and standard response stances
- Lead grading rules (A/B/C)
- Opportunity maturity stages
- Sales risk identification boundaries (sales/project progress only)
- Generic B2B CRM fields template
- Information source policy and conflict resolution

### Out of scope
- Legal/tax/compliance/audit opinions
- Contract review opinions
- Credit rating opinions
- Use of non-public, paid, unauthorized, privacy, rumor-based data

## Sources
- **user_material_markdown_001:** 客户信息收集员-业务资料整理文档（用户粘贴，用户确认作为本轮权威来源）

## Core Concepts (high level)
- **Customer**: 客户公司主体（名称、行业、规模、地区、官网、简介）
- **Contact**: 联系人（姓名、职位、部门、联系方式；仅限用户提供或授权）
- **Project**: 项目/需求（背景、现状、痛点、核心需求、预算、启动时间）
- **CustomerProfile**: 客户画像（企业特征/行业特征/数字化成熟度/AI成熟度/需求标签）
- **DecisionRole**: 决策角色（决策人/负责人/技术评估/业务负责人/影响者/使用者）
- **Objection**: 异议（ROI/安全/使用/预算/技术/实施风险）及推荐口径
- **LeadGradeRule**: A/B/C 线索评级规则
- **OpportunityMaturityStage**: 商机成熟度阶段
- **SalesRisk**: 成交/推进风险（仅销售推进维度，不含法务财税合规）
- **CRMRecord**: 通用 B2B CRM 标准录入结构
- **SourcePolicy**: 信息来源优先级与冲突处理规则

## Key Relations
- Customer has_contact Contact
- Customer has_project Project
- Customer has_profile CustomerProfile
- Customer has_decision_role DecisionRole
- Customer has_objection Objection
- Customer has_sales_risk SalesRisk
- Customer has_crm_record CRMRecord

## Constraints (must)
1. 用户提供信息优先于公开信息；公开补充必须标注来源。
2. 冲突信息以用户确认为准；不确定信息标注“待确认”，不得编造。
3. 禁止非公开/付费/未授权/隐私/传闻/不可验证信息。
4. 风险识别仅限成交/推进风险，不输出法务/财税/合规/审计/合同/信用意见。

## Open Questions
- 公开检索是否允许扩展到“竞品介入判断/预计成交时间”等非基础信息。

## Next Actions
- Based on this slice, generate per-skill projection contracts in projection pass.
- Then run skill-generation.
