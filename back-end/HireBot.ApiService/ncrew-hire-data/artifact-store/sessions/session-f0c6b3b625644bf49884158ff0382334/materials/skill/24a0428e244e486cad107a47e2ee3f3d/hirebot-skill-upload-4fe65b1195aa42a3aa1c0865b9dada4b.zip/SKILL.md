# Temp Skill

Diagnostic skill.
