# Vehicle Automation Levels Ontology (SAE J3016 2018)

## 概述

本文档是基于 **SAE J3016 (2018)** 标准定义的车辆自动化等级本体ontology，包含了从L0到L5的完整驾驶自动化分级体系。该本体定义了自动驾驶相关的核心概念、术语及其关系。

**来源**: SAE J3016 "Levels of Driving Automation" 标准
**版权**: © SAE International, All rights reserved.
**许可证**: MIT License

---

## 核心概念层次

### 驾驶自动化等级总览

| 等级 | 名称 | 缩写 | DDT执行者 | 用户角色 |
|------|------|------|-----------|----------|
| L0 | 无驾驶自动化 (No Driving Automation) | - | 人类驾驶员 | 完全由人类驾驶员操作 |
| L1 | 驾驶员辅助 (Driver Assistance) | Level 1 | 驾驶自动化系统 + 人类驾驶员 | 驾驶员执行部分DDT |
| L2 | 部分驾驶自动化 (Partial Driving Automation) | Level 2 | 驾驶自动化系统 + 人类驾驶员 | 驾驶员监督系统并执行OEDR |
| L3 | 条件驾驶自动化 (Conditional Driving Automation) | Level 3 | ADS | 备用驾驶员（需响应干预请求）|
| L4 | 高度驾驶自动化 (High Driving Automation) | Level 4 | ADS | 无需人类介入（特定ODD内）|
| L5 | 完全驾驶自动化 (Full Driving Automation) | Level 5 | ADS | 无需人类介入（任何ODD）|

---

## 核心术语定义

### 1. 驾驶任务相关

#### Dynamic Driving Task (DDT) - 动态驾驶任务

**定义**: 所有在道路上驾驶车辆所需的实时操作和战术功能，不包括战略功能（如行程规划、目的地选择等），包括：
- **横向车辆运动控制** - 通过转向进行操作
- **纵向车辆运动控制** - 通过加减速进行操作
- **监控驾驶环境** - 对象和事件检测、识别、分类和响应准备（操作和战术）
- **对象和事件响应执行** - (操作和战术)
- **机动规划** - (战术)
- **通过灯光、信号和手势增强醒目度** - (战术)

**缩写**: DDT
**来源**: SAE-J3016 (2018), sec. 3.13

#### Object and Event Detection and Response (OEDR)

**定义**: DDT的子任务，包括监控驾驶环境（检测、识别、分类对象和事件，并为响应做准备）和执行对这些对象和事件的适当响应。

**缩写**: OEDR
**来源**: SAE-J3016 (2018), sec. 3.20

#### DDT Fallback - DDT回退

**定义**: 在发生DDT性能相关系统故障或ODD出口后，用户执行DDT或达到最小风险条件的响应，或ADS在相同情况下达到最小风险条件的响应。

**来源**: SAE-J3016 (2018), sec. 3.14

---

### 2. 用户角色

#### Human Driver - 人类驾驶员

**定义**: 能够在物理上操作车辆执行DDT的人类。

**子类型**:
- **Conventional Driver** - 传统驾驶员：手动操作车内制动、加速、转向和变速器换档输入设备来操作车辆
- **Remote Driver** - 远程驾驶员：不坐在可手动操作输入设备的位置但能够操作车辆

#### DDT Fallback-Ready User - DDT备用驾驶员

**定义**: 配备已启用3级ADS功能的车辆的用户，该用户能够操作车辆并能接受ADS发出的干预请求以及明显的DDT性能相关系统故障。

**来源**: SAE-J3016 (2018), sec. 3.29.3

#### Passenger - 乘客

**定义**: 车辆中对操作该车辆没有角色的用户。

**来源**: SAE-J3016 (2018), sec. 3.29.2

---

### 3. 系统组件

#### Driving Automation System - 驾驶自动化系统

**定义**: 能够持续执行部分或全部DDT的硬件和软件；此术语用于描述任何1-5级驾驶自动化能力系统。

**来源**: SAE-J3016 (2018), sec. 3.8

#### Automated Driving System (ADS) - 自动驾驶系统

**定义**: 能够持续执行整个DDT的硬件和软件，无论是否限于特定的ODD；此术语特指3、4或5级驾驶自动化系统。

**缩写**: ADS
**来源**: SAE-J3016 (2018), sec. 3.2

#### Active Safety System - 主动安全系统

**定义**: 感应和监控车内外部条件，目的是识别对车辆、乘员和/或其他道路使用者的当前和潜在危险的车辆系统，并自动干预以通过各种方法帮助避免或减轻潜在碰撞，包括向驾驶员发出警报、车辆系统调整以及主动控制车辆子系统（制动、油门、悬架等）。

**来源**: SAE-J3016 (2018), sec. 3.1

---

### 4. 车辆类型

#### ADS-Dedicated Vehicle (ADS-DV) - ADS专用车辆

**定义**: 设计为仅由4级或5级ADS操作以完成其给定ODD限制内所有行程的车辆。

**示例**:
- 在公司园区内沿着ADS-DV调度器指定的特定路线接送和放下乘客的4级ADS-DV
- 在地理划定市中心内专门使用ADS-DV调度器指定的道路（而非路线）运送物资的4级ADS-DV
- 能够在所有可通行的美国道路网络上导航的5级ADS-DV

**缩写**: ADS-DV
**来源**: SAE-J3016 (2018), sec. 3.3

#### ADS Dual-Mode Vehicle - ADS双模车辆

**定义**: 设计为既可进行无人驾驶操作又可由传统驾驶员完成整个行程的ADS配备车辆。

**来源**: SAE-J3016 (2018), sec. 3.12

#### Conventional Vehicle - 传统车辆

**定义**: 设计为由传统驾驶员在部分或全部行程中操作的车辆。

**来源**: SAE-J3016 (2018), sec. 3.5

---

### 5. 操作概念

#### Driverless Operation - 无人驾驶操作

**定义**: ADS配备车辆的操作，其中不存在车载用户，或车载用户不是驾驶员或备用用户。

**来源**: SAE-J3016 (2018), sec. 3.11

#### Operation with Driver - 有驾驶员操作

**定义**: 有人类驾驶员在场时车辆的操作。

#### Dispatch in Driverless Operation - 无人驾驶操作调度

**定义**: 通过启用ADS将ADS配备车辆置于无人驾驶操作服务中。

**来源**: SAE-J3016 (2018), sec. 3.6

#### Request to Intervene - 干预请求

**定义**: ADS向备用驾驶员发出的通知，表明他应立即执行DDT回退，这可能涉及恢复手动操作车辆（即再次成为驾驶员），或者如果车辆不可行驶则达到最小风险条件。

**来源**: SAE-J3016 (2018), sec. 3.24

---

### 6. 操作设计域 (ODD)

#### Operational Design Domain (ODD) - 操作设计域

**定义**: 特定驾驶自动化系统或其功能被专门设计运行的条件，包括但不限于环境、地理和时间限制，以及某些交通或道路特征的存在或不存在。

**缩写**: ODD
**来源**: SAE-J3016 (2018), sec. 3.22

#### Operating Conditions - 操作条件

ODD由以下操作条件组成：
- **地理条件** (ConfinedGeographicLocation): 校园、商业区、市中心、住宅区、停车场等
- **道路类型** (RoadType): 高速公路等
- **速度限制** (SpeedLimit): 25km/h, 30km/h, 40km/h, 50km/h, 60km/h, 70km/h, 80km/h
- **交通类型** (TrafficType): 拥堵交通、停走交通
- **天气类型** (WeatherType): 晴天、雾天、下雨天
- **道路维护** (RoadMaintenance): 最佳道路维护、较差道路维护
- **时间** (TimeOfDay): 日光

**示例ODD**:
- "高速公路，拥堵交通"
- "高速公路，低速，最佳道路维护，晴天"
- "公司园区，特定路线"
- "指定的市中心区域"

---

## 各自动化等级详细定义

### Level 0: 无驾驶自动化 (No Driving Automation)

**定义**: 由人类驾驶员执行全部DDT，无任何驾驶自动化系统执行部分DDT。

**说明**: 包括主动安全系统等暂时性干预系统（如ABS、电子稳定控制、自动紧急制动）不构成持续驾驶自动化，不属于本分类。

---

### Level 1: 驾驶员辅助 (Driver Assistance)

**缩写**: Level 1

**定义**: 驾驶自动化系统持续在特定ODD内执行DDT的横向或纵向车辆运动控制子任务（但不是同时执行两者），期望驾驶员执行DDT的其余部分。

**来源**: SAE-J3016 (2018), sec. 5.2

**特点**:
- 系统执行横向或纵向车辆运动控制之一（非同时）
- 驾驶员必须完成OEDR子任务
- 驾驶员必须监督系统性能

---

### Level 2: 部分驾驶自动化 (Partial Driving Automation)

**缩写**: Level 2

**定义**: 驾驶自动化系统持续在特定ODD内执行DDT的横向和纵向车辆运动控制子任务，期望驾驶员完成OEDR子任务并监督驾驶自动化系统。

**来源**: SAE-J3016 (2018), sec. 5.3

**特点**:
- 系统同时执行横向和纵向车辆运动控制
- 驾驶员执行OEDR并监督系统
- 系统能力有限，某些事件无法识别或响应

---

### Level 3: 条件驾驶自动化 (Conditional Driving Automation)

**缩写**: Level 3

**定义**: ADS在特定ODD内持续执行整个DDT，期望DDT备用驾驶员对ADS发出的干预请求以及DDT性能相关系统故障做出适当响应。

**来源**: SAE-J3016 (2018), sec. 5.4

**特点**:
- ADS执行整个DDT（包括OEDR）
- 驾驶员不需要监督，但必须准备响应干预请求
- 发生系统故障时，ADS会发出干预请求
- 驾驶员需要能够在合理时间内响应

**示例**: 在低速停走交通中执行整个DDT的ADS功能。

---

### Level 4: 高度驾驶自动化 (High Driving Automation)

**缩写**: Level 4

**定义**: ADS在特定ODD内持续执行整个DDT和DDT回退，不期望用户响应干预请求。

**来源**: SAE-J3016 (2018), sec. 5.5

**特点**:
- ADS执行整个DDT和DDT回退
- 无需人类用户在环
- 限定于特定ODD
- 可以实现最小风险条件

**示例**:
- 在地理围栏城市中心执行DDT的ADS功能
- 在封闭园区执行DDT的ADS-DV

---

### Level 5: 完全驾驶自动化 (Full Driving Automation)

**缩写**: Level 5

**定义**: ADS持续无条件的（即非ODD特定的）执行整个DDT和DDT回退，不期望用户响应干预请求。

**来源**: SAE-J3016 (2018), sec. 5.6

**特点**:
- ADS执行整个DDT和DDT回退
- 无条件执行，不限定于特定ODD
- 无需任何人类介入
- 适用于所有道路和环境条件

**示例**: 一旦编程了目的地，车辆ADS就能够在整个行程中操作车辆，无论起点、终点或之间的道路、交通和天气状况如何。

---

## 关键概念层级关系

```
DrivingAutomation
├── NoDrivingAutomation (Level 0)
├── DriverSupport (Level 1-2)
│   ├── DriverAssistance (Level 1)
│   │   └── 执行横向 OR 纵向控制
│   └── PartialDrivingAutomation (Level 2)
│       └── 执行横向 AND 纵向控制
└── AutomatedDriving (Level 3-5)
    ├── ConditionalDrivingAutomation (Level 3)
    │   └── ADS执行DDT，需要备用驾驶员
    ├── HighDrivingAutomation (Level 4)
    │   └── ADS执行DDT+回退，无需用户
    └── FullDrivingAutomation (Level 5)
        └── ADS执行DDT+回退，无条件
```

---

## DDT性能相关系统故障 (DDT Performance-Relevant System Failure)

**定义**: 驾驶自动化系统和/或其他车辆系统中的故障，阻止驾驶自动化系统可靠地持续执行其本来会执行的DDT部分（包括整个DDT）。

**来源**: SAE-J3016 (2018), sec. 3.18

**说明**:
- 适用于驾驶自动化系统无法按设计意图全能力执行的车辆故障条件
- 不适用于由于固有设计限制导致的暂时性性能下降

---

## 最小风险条件 (Minimal Risk Condition)

**定义**: 不存在不合理风险的条件，包括：
- 由ADS实现的稳定停止状态
- 由驾驶员实现的稳定停止状态
- 由ADS或驾驶员实现的紧急停止状态

**相关**: DDT Fallback操作

---

## 本体属性 (Object Properties)

| 属性 | 定义 |
|------|------|
| `hasFeature` | 连接驾驶自动化系统与其功能 |
| `hasOperatingCondition` | 将ODD与操作条件关联 |
| `hasUsageSpecification` | 将特定自动化等级与相应ODD关联 |
| `hasUserAtAllTimes` | 将车辆持续操作与人类用户角色关联 |
| `hasUserWhileDASisEnagaged` | 连接启用时自动化等级与人类用户角色 |
| `isCapableToParticipateIn` | 连接能够参与特定操作的机动车辆 |
| `isEquippedWith` | 连接装备有ADS的车辆 |
| `isPerformedBy` | 指示执行操作的主体 |
| `performs` | 链接过程与其结果 |
| `realizes` | 链接功能与实现的等级 |
| `isReceptiveTo` | 人类用户对刺激的注意力能力 |

---

## 参考来源

- SAE J3016 (2018) "Levels of Driving Automation" 标准
- 本体来源: https://spec.edmcouncil.org/auto/ontology/AV/VehicleAutomationLevels_2018/

---

*注：SAE J3016™ 是SAE International的商标。SAE标准的真正权威版本是PDF版本，可在上找到。*